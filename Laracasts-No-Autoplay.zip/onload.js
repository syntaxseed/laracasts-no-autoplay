/**
 * Main behaviour of extension. Executes on load of tab.
 */

// Begin main function of extension:
listenForEndOfVideo();
