/**
 * Main behaviour of extension. Executes on load of any tab.
 */

// Begin main function of extension:
listenForEndOfVideo();
