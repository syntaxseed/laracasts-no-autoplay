/**
 * Chrome extension
 * Set up event listeners and background js.
 */


// Listener for when extension icon is clicked.
/*
chrome.action.onClicked.addListener((tab) => {
    chrome.scripting.executeScript({
      target: {tabId: tab.id},
      files: ['main.js']
    });
});
*/